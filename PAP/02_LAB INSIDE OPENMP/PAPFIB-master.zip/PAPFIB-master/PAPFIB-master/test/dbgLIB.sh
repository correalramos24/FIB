#! /bin/bash

cd ../src/
echo "compiling LIB with debug option"
make dbg=1
