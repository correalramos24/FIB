
ENVIROMENT SET UP

The scripts have been written in python 3.7.

For install the python 3.7 (the higher version are compatible) check the web :
https://www.python.org/downloads/

Also, the numpy library is necesari, for install packages the pip3 is necesary. 
to install the package : pip3 install numpy

The diferent scripts can be executed with a console and execute with the python3 
interpreter (python3 script_name.py). Is important tu run like this because it is
necessary to write the path to the data files.

====USER MANUAL====

* All the scripts have the same interface, they ask for a file (with a concrete format) 
that contain the tasks information.
Once the test is endend, a new file can be used to perform a new test.
* To exit the script, a keyboard interrupt is necessary (Ctrl C).
* For a help with the concrete file format, type *file and the help will appear