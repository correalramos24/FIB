## Tema 2 - Mecanismes d'entrada al sistema

### Procediment entrada a sistema

Modes execucció CPU (hw)

### Excepcions

### Interrupcions

### System Calls

