# LABORATORIS IDI QT 2017-2018

- Està organitzat per blocs on cada bloc té les diverses sessions que es van realitzant.
- Dintre de cada sessií hi ha un directori per cada un dels exercicis que es fan en aquella sessió.


* Si trobes algun error, o simplement vols fer algun comentari, em pots escriure a florencia.rimolo@est.fib.upc.edu.

------------------------------------------------------------------------------------------


Made with <3 in Barcelona
